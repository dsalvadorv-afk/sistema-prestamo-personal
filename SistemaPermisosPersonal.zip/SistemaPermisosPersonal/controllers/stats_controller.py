from functools import reduce
from core.console import color, BOLD, RED, GREEN, YELLOW, CYAN, WHITE
from core import JsonManager, operation_title


class StatsController:

    EMPLOYEES_FILE   = "data/employees.json"
    TYPES_FILE       = "data/permission_types.json"
    PERMISSIONS_FILE = "data/permissions.json"

    def __init__(self):
        self.employees        = JsonManager(StatsController.EMPLOYEES_FILE).load()
        self.permission_types = JsonManager(StatsController.TYPES_FILE).load()
        self.permissions      = JsonManager(StatsController.PERMISSIONS_FILE).load()

    def _refresh(self):
        self.employees        = JsonManager(StatsController.EMPLOYEES_FILE).load()
        self.permission_types = JsonManager(StatsController.TYPES_FILE).load()
        self.permissions      = JsonManager(StatsController.PERMISSIONS_FILE).load()

    @operation_title("ESTADÍSTICAS DE PERMISOS")
    def show(self):
        self._refresh()

        total_employees   = len(self.employees)
        total_permissions = len(self.permissions)

        paid_permissions   = list(filter(lambda p: p["remunerado"] == "S", self.permissions))
        unpaid_permissions = list(filter(lambda p: p["remunerado"] == "N", self.permissions))

        total_time     = reduce(lambda acc, p: acc + p["tiempo"],    self.permissions, 0)
        total_discount = reduce(lambda acc, p: acc + p["descuento"], self.permissions, 0)

        time_labels = list(map(
            lambda p: f"{p['tiempo']} {'día(s)' if p['tipo'] == 'D' else 'hora(s)'}",
            self.permissions
        ))

        print(color("  Total empleados:              ", CYAN) + color(str(total_employees),   YELLOW, BOLD))
        print(color("  Total permisos:               ", CYAN) + color(str(total_permissions), YELLOW, BOLD) + "\n")
        print(color("  Permisos remunerados:         ", CYAN) + color(str(len(paid_permissions)),   GREEN, BOLD))
        print(color("  Permisos no remunerados:      ", CYAN) + color(str(len(unpaid_permissions)), RED,   BOLD) + "\n")
        print(color("  Total horas/días solicitados: ", CYAN) + color(str(total_time), YELLOW, BOLD))
        print(color("  Detalle de tiempo: ", CYAN) + color(", ".join(time_labels) if time_labels else "—", WHITE) + "\n")
        print(color("  Monto total descontado:       ", CYAN) + color(f"${total_discount:.2f}", GREEN, BOLD))
