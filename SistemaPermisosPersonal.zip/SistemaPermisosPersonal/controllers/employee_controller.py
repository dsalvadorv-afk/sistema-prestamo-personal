from core.console import color, BOLD, RED, GREEN, YELLOW, BLUE, CYAN, WHITE
from core import (
    CrudInterface,
    JsonManager,
    ValidationMixin,
    LogMixin,
    handle_errors,
    operation_title,
    ask_continue,
)
from models import Employee
from core.mixins import InputMixin


class EmployeeController(CrudInterface, ValidationMixin, LogMixin, InputMixin):

    DATA_FILE = "data/employees.json"

    def __init__(self):
        self.db = JsonManager(EmployeeController.DATA_FILE)
        self.employees = self.db.load()

    def _next_id(self):
        if not self.employees:
            return 1
        return max(emp["employee_id"] for emp in self.employees) + 1

    @ask_continue("¿Registrar otro empleado? (s/n): ")
    @handle_errors
    @operation_title("REGISTRO DE EMPLEADO")
    def create(self):
        employee_id = self._next_id()
        print(color(f"  ID: {employee_id} ", YELLOW) + color("[GENERADO AUTOMÁTICAMENTE]", GREEN))

        name = self.input_name()
        salary = self.input_float("Sueldo: ")
        id_number = self.input_id_number()
        
        for employee in self.employees:
            if employee["cedula"] == id_number:
                print(color("  ✖  Esa cédula ya ha sido registrada.", RED, BOLD))
                self.pause()
                return

        employee = Employee(employee_id, name, id_number, salary)

        print(color("  " + "─" * 46, YELLOW))
        print(color(f"  Valor hora calculado: ${employee.hourly_rate:.2f}", GREEN, BOLD))
        print(color("  " + "─" * 46, YELLOW))
        print(color("  ¿Desea guardar?", CYAN, BOLD))
        print(color("  [1]", BLUE, BOLD) + color("  Sí", WHITE))
        print(color("  [2]", BLUE, BOLD) + color("  No", WHITE))
        option = self.get_valid_option(
            "Seleccione opción: ",
            ["1", "2"]
        )

        if option == "1":
            self.employees.append(employee.to_dict())
            self.db.save(self.employees)
            self.log("Empleado registrado correctamente")
            self.pause()
        else:
            print(color("  Registro cancelado.", YELLOW))
            self.pause()

    @operation_title("LISTA DE EMPLEADOS")
    def read(self):
        if not self.employees:
            print(color("  No hay empleados registrados.", YELLOW))
            self.pause()
            return
        for employee_data in self.employees:
            print(Employee.from_dict(employee_data).display_name)
        self.pause()

    @handle_errors
    @operation_title("ACTUALIZAR EMPLEADO")
    def update(self):
        employee_id = int(input("ID del empleado: "))
        for employee in self.employees:
            if employee["employee_id"] == employee_id:
                name = self.input_name()
                salary = self.input_float("Nuevo sueldo: ")
                id_number = self.input_id_number()
                
                for emp in self.employees:
                    if emp["cedula"] == id_number and emp["employee_id"] != employee_id:
                        print(color("  ✖  Esa cédula ya ha sido registrada.", RED, BOLD))
                        input(color("  Presione Enter para continuar...", YELLOW))
                        return

                self.validate_not_empty(salary, "Sueldo")
                self.validate_positive_number(salary, "Sueldo")

                updated = Employee(employee_id, name, id_number, salary)
                employee.update(updated.to_dict())
                self.db.save(self.employees)
                self.log("Empleado actualizado")
                self.pause()
                return
        print(color("  ✖  Empleado no encontrado.", RED, BOLD))
        self.pause()

    @handle_errors
    @operation_title("ELIMINAR EMPLEADO")
    def delete(self):
        employee_id = int(input("ID del empleado: "))
        for employee in self.employees:
            if employee["employee_id"] == employee_id:
                self.employees.remove(employee)
                self.db.save(self.employees)
                self.log("Empleado eliminado")
                self.pause()
                return
        print(color("  ✖  Empleado no encontrado.", RED, BOLD))
        self.pause()
