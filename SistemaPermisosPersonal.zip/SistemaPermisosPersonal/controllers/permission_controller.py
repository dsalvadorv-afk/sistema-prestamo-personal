from core.console import color, BOLD, RED, GREEN, YELLOW, BLUE, CYAN, WHITE
from core import (
    CrudInterface,
    JsonManager,
    ValidationMixin,
    LogMixin,
    SearchMixin,
    DiscountMixin,
    handle_errors,
    operation_title,
    ask_continue,
)
from models import Permission
from core.mixins import InputMixin


class PermissionController(CrudInterface, ValidationMixin, LogMixin, SearchMixin, DiscountMixin, InputMixin):

    PERMISSIONS_FILE = "data/permissions.json"
    EMPLOYEES_FILE   = "data/employees.json"
    TYPES_FILE       = "data/permission_types.json"

    def __init__(self):
        self.permissions_db = JsonManager(PermissionController.PERMISSIONS_FILE)
        self.employees_db   = JsonManager(PermissionController.EMPLOYEES_FILE)
        self.types_db       = JsonManager(PermissionController.TYPES_FILE)
        self.permissions     = self.permissions_db.load()
        self.employees       = self.employees_db.load()
        self.permission_types = self.types_db.load()

    def _input_int(self, message):
        while True:
            value = input(message)
            if value.isdigit():
                return int(value)
            print("Error: debe ingresar solo números.")

    def _input_text(self, message, valid_values=None):
        while True:
            value = input(message).strip()
            if not value:
                print("Error: este campo no puede estar vacío.")
                continue

            if valid_values and value.upper() not in valid_values:
                print(f"Error: opción inválida. Use {valid_values}")
                continue

            return value.upper() if valid_values else value

    def _input_date(self, message):
        while True:
            raw = input(message).strip()

            if len(raw) != 10 or raw[4] != "-" or raw[7] != "-":
                print("Error: formato incorrecto. Use AAAA-MM-DD (ej: 2026-02-28)")
                continue

            if not (raw[:4].isdigit() and raw[5:7].isdigit() and raw[8:10].isdigit()):
                print("Error: la fecha solo debe contener números y guiones.")
                continue

            try:
                date_obj = self.validate_date(raw, message)
                return raw, date_obj
            except ValueError:
                print("Error: la fecha no existe o es inválida.")

    def _resolve_time(self, kind, start_date, end_date):
        if kind == "D":
            duration = float((end_date - start_date).days + 1)
            print(color(f"  Tiempo calculado automáticamente: {int(duration)} día(s)", GREEN))
            return duration
        else:
            return self.input_float("Tiempo (horas): ")

    def _reload_external_data(self):
        self.employees        = self.employees_db.load()
        self.permission_types = self.types_db.load()

    def _next_id(self):
        if not self.permissions:
            return 1
        return max(p["permission_id"] for p in self.permissions) + 1

    @ask_continue("¿Registrar otro permiso? (s/n): ")
    @handle_errors
    @operation_title("REGISTRO DE PERMISO")
    def create(self):
        self._reload_external_data()
        permission_id = self._next_id()
        print(color(f"  ID: {permission_id} ", YELLOW) + color("[GENERADO AUTOMÁTICAMENTE]", GREEN))

        employee_id        = self._input_int("ID Empleado: ")
        permission_type_id = self._input_int("ID Tipo Permiso: ")

        employee        = self.find_by_id(self.employees, "employee_id", employee_id)
        permission_type = self.find_by_id(self.permission_types, "permission_type_id", permission_type_id)

        if employee is None:
            raise ValueError("Error: el empleado no existe.")
        if permission_type is None:
            raise ValueError("Error: el tipo de permiso no existe.")

        start_date_str, start_date = self._input_date("Fecha desde (AAAA-MM-DD): ")
        end_date_str,   end_date   = self._input_date("Fecha hasta (AAAA-MM-DD): ")
        self.validate_date_range(start_date, end_date)

        kind = self._input_text("Tipo (D/H): ", valid_values=["D", "H"])

        duration = self._resolve_time(kind, start_date, end_date)
        self.validate_positive_number(duration, "Tiempo")

        discount = self.calculate_discount(employee, permission_type, kind, duration)
        paid     = permission_type["remunerado"]

        print(color("  " + "─" * 46, YELLOW))
        print(color("  Resumen:", CYAN, BOLD))
        print(color(f"  Empleado: {employee['nombre']}", WHITE))
        print(color(f"  Tipo de permiso: {permission_type['descripcion']}", WHITE))
        print(color(f"  ¿Remunerado?: {paid}", WHITE))
        print(color(f"  Descuento aplicado: ${discount:.2f}", GREEN, BOLD))
        print(color("  " + "─" * 46, YELLOW))

        option = self._input_text("Confirmar (S/N): ", valid_values=["S", "N"])

        if option == "S":
            permission = Permission(
                permission_id=permission_id,
                employee_id=employee_id,
                permission_type_id=permission_type_id,
                start_date=start_date_str,
                end_date=end_date_str,
                kind=kind,
                duration=duration,
                paid=paid,
                discount=discount,
            )
            self.permissions.append(permission.to_dict())
            self.permissions_db.save(self.permissions)
            self.log("Permiso registrado correctamente")
            self.pause()
        else:
            print(color("  Registro cancelado.", YELLOW))
            self.pause()

    @operation_title("LISTA DE PERMISOS")
    def read(self):
        if not self.permissions:
            print(color("  No hay permisos registrados.", YELLOW))
            self.pause()
            return
        for p in self.permissions:
            print(Permission.from_dict(p).display_name)
        self.pause()

    @handle_errors
    @operation_title("ACTUALIZAR PERMISO")
    def update(self):
        self._reload_external_data()

        permission_id = self._input_int("ID del permiso: ")

        for permission in self.permissions:
            if permission["permission_id"] == permission_id:

                employee_id        = self._input_int("Nuevo ID empleado: ")
                permission_type_id = self._input_int("Nuevo ID tipo permiso: ")

                employee        = self.find_by_id(self.employees, "employee_id", employee_id)
                permission_type = self.find_by_id(self.permission_types, "permission_type_id", permission_type_id)

                if employee is None:
                    raise ValueError("Error: empleado no existe.")
                if permission_type is None:
                    raise ValueError("Error: tipo de permiso no existe.")

                start_date_str, start_date = self._input_date("Nueva fecha desde (AAAA-MM-DD): ")
                end_date_str,   end_date   = self._input_date("Nueva fecha hasta (AAAA-MM-DD): ")
                self.validate_date_range(start_date, end_date)

                kind = self._input_text("Nuevo tipo (D/H): ", valid_values=["D", "H"])

                duration = self._resolve_time(kind, start_date, end_date)
                self.validate_positive_number(duration, "Tiempo")

                discount = self.calculate_discount(employee, permission_type, kind, duration)

                updated = Permission(
                    permission_id,
                    employee_id,
                    permission_type_id,
                    start_date_str,
                    end_date_str,
                    kind,
                    duration,
                    permission_type["remunerado"],
                    discount,
                )

                permission.update(updated.to_dict())
                self.permissions_db.save(self.permissions)
                self.log("Permiso actualizado")
                self.pause()
                return

        print(color("  ✖  Permiso no encontrado.", RED, BOLD))
        self.pause()

    @handle_errors
    @operation_title("ELIMINAR PERMISO")
    def delete(self):
        permission_id = self._input_int("ID del permiso: ")

        for permission in self.permissions:
            if permission["permission_id"] == permission_id:
                self.permissions.remove(permission)
                self.permissions_db.save(self.permissions)
                self.log("Permiso eliminado")
                self.pause()
                return

        print(color("  ✖  Permiso no encontrado.", RED, BOLD))
        self.pause()
