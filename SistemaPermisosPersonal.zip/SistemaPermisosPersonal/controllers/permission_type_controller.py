from core.console import color, BOLD, RED, GREEN, YELLOW, BLUE, CYAN, WHITE
from core import (
    CrudInterface,
    JsonManager,
    ValidationMixin,
    LogMixin,
    handle_errors,
    operation_title,
    ask_continue,
)
from models import PermissionType
from core.mixins import InputMixin


class PermissionTypeController(CrudInterface, ValidationMixin, LogMixin, InputMixin):

    DATA_FILE = "data/permission_types.json"

    def __init__(self):
        self.db = JsonManager(PermissionTypeController.DATA_FILE)
        self.permission_types = self.db.load()

    def _next_id(self):
        if not self.permission_types:
            return 1
        return max(item["permission_type_id"] for item in self.permission_types) + 1

    @ask_continue("¿Registrar otro tipo de permiso? (s/n): ")
    @handle_errors
    @operation_title("TIPO DE PERMISO")
    def create(self):
        permission_type_id = self._next_id()
        print(color(f"  ID: {permission_type_id} ", YELLOW) + color("[GENERADO AUTOMÁTICAMENTE]", GREEN))

        description = input("Descripción: ")
        paid = self.input_yes_no("¿Remunerado? (S/N): ")

        self.validate_not_empty(description, "Descripción")
        paid = self.validate_yes_no(paid, "Remunerado")

        permission_type = PermissionType(permission_type_id, description, paid)

        print(color("\n  ¿Guardar?", CYAN, BOLD))
        print(color("  [1]", BLUE, BOLD) + color("  Sí", WHITE))
        print(color("  [2]", BLUE, BOLD) + color("  No", WHITE))
        option = self.get_valid_option(
            "Seleccione opción: ",
            ["1", "2"]
        )

        if option == "1":
            self.permission_types.append(permission_type.to_dict())
            self.db.save(self.permission_types)
            self.log("Tipo de permiso registrado correctamente")
            self.pause()
        else:
            print(color("  Registro cancelado.", YELLOW))
            self.pause()

    @operation_title("LISTA DE TIPOS DE PERMISO")
    def read(self):
        if not self.permission_types:
            print(color("  No hay tipos de permiso registrados.", YELLOW))
            self.pause()
            return
        for item in self.permission_types:
            print(PermissionType.from_dict(item).display_name)
        self.pause()

    @handle_errors
    @operation_title("ACTUALIZAR TIPO DE PERMISO")
    def update(self):
        permission_type_id = int(input("ID del tipo de permiso: "))
        for item in self.permission_types:
            if item["permission_type_id"] == permission_type_id:
                description = input("Nueva descripción: ")
                paid = input("¿Remunerado? (S/N): ")

                self.validate_not_empty(description, "Descripción")
                paid = self.validate_yes_no(paid, "Remunerado")

                updated = PermissionType(permission_type_id, description, paid)
                item.update(updated.to_dict())
                self.db.save(self.permission_types)
                self.log("Tipo de permiso actualizado")
                self.pause()
                return
        print(color("  ✖  Tipo de permiso no encontrado.", RED, BOLD))
        self.pause()

    @handle_errors
    @operation_title("ELIMINAR TIPO DE PERMISO")
    def delete(self):
        permission_type_id = int(input("ID del tipo de permiso: "))
        for item in self.permission_types:
            if item["permission_type_id"] == permission_type_id:
                self.permission_types.remove(item)
                self.db.save(self.permission_types)
                self.log("Tipo de permiso eliminado")
                self.pause()
                return
        print(color("  ✖  Tipo de permiso no encontrado.", RED, BOLD))
        self.pause()
