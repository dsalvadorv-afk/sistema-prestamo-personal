from controllers import (
    EmployeeController,
    PermissionTypeController,
    PermissionController,
    StatsController,
)
from core.console import (
    gotoxy, clear, color, title_box, separator,
    BOLD, CYAN, BLUE, GREEN, YELLOW, RED, MAGENTA, WHITE, RESET,
)


class Menu:

    def __init__(self):
        self.employee_controller       = EmployeeController()
        self.permission_type_controller = PermissionTypeController()
        self.permission_controller     = PermissionController()

    def _invalid_option(self):
        print(color("  ✖  Opción inválida. Intente de nuevo.", RED, BOLD))
        input(color("  Presione Enter para continuar...", YELLOW))

    def _header(self, title: str) -> None:
        clear()
        gotoxy(1, 1)
        width  = 50
        border = "═" * width
        print(color(f"╔{border}╗", CYAN, BOLD))
        print(color(f"║{'SISTEMA DE REGISTRO DE PERMISOS'.center(width)}║", CYAN, BOLD))
        print(color(f"╚{border}╝", CYAN, BOLD))
        print()
        gotoxy(1, 5)
        separator(50, "─")
        gotoxy(1, 6)
        print(color(f"  {title}", YELLOW, BOLD))
        gotoxy(1, 7)
        separator(50, "─")
        print()

    def _option(self, num: str, text: str) -> None:
        print(color(f"  [{num}]", BLUE, BOLD) + color(f"  {text}", WHITE))

    def employee_menu(self):
        options = {
            "1": self.employee_controller.create,
            "2": self.employee_controller.read,
            "3": self.employee_controller.update,
            "4": self.employee_controller.delete,
        }

        while True:
            self._header("MENÚ EMPLEADOS")
            self._option("1", "Registrar empleado")
            self._option("2", "Consultar empleados")
            self._option("3", "Actualizar empleado")
            self._option("4", "Eliminar empleado")
            print()
            self._option("0", "Volver")
            print()
            separator(50, "─")

            option = input(color("  Opción: ", CYAN, BOLD))

            if option == "0":
                break

            action = options.get(option)

            if action:
                action()
            else:
                self._invalid_option()

    def permission_type_menu(self):
        options = {
            "1": self.permission_type_controller.create,
            "2": self.permission_type_controller.read,
            "3": self.permission_type_controller.update,
            "4": self.permission_type_controller.delete,
        }

        while True:
            self._header("MENÚ TIPO DE PERMISO")
            self._option("1", "Registrar tipo de permiso")
            self._option("2", "Consultar tipos de permiso")
            self._option("3", "Actualizar tipo de permiso")
            self._option("4", "Eliminar tipo de permiso")
            print()
            self._option("0", "Volver")
            print()
            separator(50, "─")

            option = input(color("  Opción: ", CYAN, BOLD))

            if option == "0":
                break

            action = options.get(option)

            if action:
                action()
            else:
                self._invalid_option()

    def permission_menu(self):
        options = {
            "1": self.permission_controller.create,
            "2": self.permission_controller.read,
            "3": self.permission_controller.update,
            "4": self.permission_controller.delete,
        }

        while True:
            self._header("MENÚ PERMISOS")
            self._option("1", "Registrar permiso")
            self._option("2", "Consultar permisos")
            self._option("3", "Actualizar permiso")
            self._option("4", "Eliminar permiso")
            print()
            self._option("0", "Volver")
            print()
            separator(50, "─")

            option = input(color("  Opción: ", CYAN, BOLD))

            if option == "0":
                break

            action = options.get(option)

            if action:
                action()
            else:
                self._invalid_option()

    def stats_menu(self):
        clear()
        gotoxy(1, 1)
        StatsController().show()
        print()
        input(color("  Presione Enter para volver...", YELLOW))

    def main_menu(self):
        options = {
            "1": self.employee_menu,
            "2": self.permission_type_menu,
            "3": self.permission_menu,
            "4": self.stats_menu,
        }

        while True:
            clear()
            gotoxy(1, 1)

            width  = 50
            border = "═" * width
            print()
            print(color(f"  ╔{border}╗", CYAN, BOLD))
            print(color(f"  ║{'SISTEMA DE REGISTRO DE PERMISOS'.center(width)}║", CYAN, BOLD))
            print(color(f"  ╚{border}╝", CYAN, BOLD))
            print()

            gotoxy(1, 8)
            separator(54, "─")
            gotoxy(1, 9)
            print(color("  MENÚ PRINCIPAL", YELLOW, BOLD))
            gotoxy(1, 10)
            separator(54, "─")
            print()

            self._option("1", "Registro de empleado")
            self._option("2", "Registro de tipo de permiso")
            self._option("3", "Registro de permiso")
            self._option("4", "Estadísticas")
            print()
            self._option("0", color("Salir", RED))
            print()
            separator(54, "─")

            option = input(color("  Opción: ", CYAN, BOLD))

            if option == "0":
                clear()
                gotoxy(1, 1)
                print()
                print(color("  ✔  Sistema finalizado. ¡Hasta pronto!", GREEN, BOLD))
                print()
                break

            action = options.get(option)

            if action:
                action()
            else:
                self._invalid_option()