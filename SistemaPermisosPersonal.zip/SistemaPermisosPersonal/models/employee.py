class Employee:

    MONTHLY_HOURS = 240

    def __init__(self, employee_id, name, id_number, salary):
        self._employee_id = employee_id
        self.name = name
        self.id_number = id_number
        self.salary = salary

    @property
    def employee_id(self):
        return self._employee_id

    @property
    def hourly_rate(self):
        return round(self.salary / Employee.MONTHLY_HOURS, 2)

    @property
    def display_name(self):
        return (
            f"ID {self.employee_id} - {self.name} - Cédula: {self.id_number} - "
            f"Sueldo: ${self.salary:.2f} - Valor hora: ${self.hourly_rate:.2f}"
        )

    def to_dict(self):
        return {
            "employee_id": self.employee_id,
            "nombre": self.name,
            "cedula": self.id_number,
            "sueldo": self.salary,
            "valor_hora": self.hourly_rate,
        }

    @staticmethod
    def from_dict(data):
        return Employee(
            employee_id=data["employee_id"],
            name=data["nombre"],
            id_number=data["cedula"],
            salary=data["sueldo"],
        )
