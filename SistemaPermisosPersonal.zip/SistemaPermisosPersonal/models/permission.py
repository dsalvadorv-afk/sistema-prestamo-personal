class Permission:

    def __init__(self, permission_id, employee_id, permission_type_id, start_date,
                 end_date, kind, duration, paid, discount):
        self._permission_id = permission_id
        self.employee_id = employee_id
        self.permission_type_id = permission_type_id
        self.start_date = start_date
        self.end_date = end_date
        self.kind = kind.upper()
        self.duration = duration
        self.paid = paid.upper()
        self.discount = discount

    @property
    def permission_id(self):
        return self._permission_id

    @property
    def kind_label(self):
        return "Días" if self.kind == "D" else "Horas"

    @property
    def display_name(self):
        return (
            f"ID {self.permission_id} - Empleado ID: {self.employee_id} - "
            f"Tipo permiso ID: {self.permission_type_id} - {self.start_date} a {self.end_date} - "
            f"{self.duration} {self.kind_label} - Descuento: ${self.discount:.2f}"
        )

    def to_dict(self):
        return {
            "permission_id": self.permission_id,
            "employee_id": self.employee_id,
            "permission_type_id": self.permission_type_id,
            "fecha_desde": self.start_date,
            "fecha_hasta": self.end_date,
            "tipo": self.kind,
            "tiempo": self.duration,
            "remunerado": self.paid,
            "descuento": self.discount,
        }

    @staticmethod
    def from_dict(data):
        return Permission(
            permission_id=data["permission_id"],
            employee_id=data["employee_id"],
            permission_type_id=data["permission_type_id"],
            start_date=data["fecha_desde"],
            end_date=data["fecha_hasta"],
            kind=data["tipo"],
            duration=data["tiempo"],
            paid=data["remunerado"],
            discount=data["descuento"],
        )
