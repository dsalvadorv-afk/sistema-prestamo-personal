class PermissionType:

    def __init__(self, permission_type_id, description, paid):
        self._permission_type_id = permission_type_id
        self.description = description
        self.paid = paid.upper()

    @property
    def permission_type_id(self):
        return self._permission_type_id

    @property
    def is_paid(self):
        return self.paid == "S"

    @property
    def display_name(self):
        status = "Remunerado" if self.is_paid else "No remunerado"
        return f"ID {self.permission_type_id} - {self.description} - {status}"

    def to_dict(self):
        return {
            "permission_type_id": self.permission_type_id,
            "descripcion": self.description,
            "remunerado": self.paid,
        }

    @staticmethod
    def from_dict(data):
        return PermissionType(
            permission_type_id=data["permission_type_id"],
            description=data["descripcion"],
            paid=data["remunerado"],
        )
