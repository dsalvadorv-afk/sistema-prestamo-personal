import os

RESET   = "\033[0m"
BOLD    = "\033[1m"

RED     = "\033[91m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
BLUE    = "\033[94m"
MAGENTA = "\033[95m"
CYAN    = "\033[96m"
WHITE   = "\033[97m"

BG_BLUE  = "\033[44m"
BG_CYAN  = "\033[46m"
BG_BLACK = "\033[40m"


def gotoxy(x: int, y: int) -> None:
    print(f"\033[{y};{x}H", end="", flush=True)


def clear() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def color(text: str, *codes: str) -> str:
    return "".join(codes) + str(text) + RESET


def title_box(text: str, width: int = 50) -> None:
    border = "═" * width
    print(color(f"╔{border}╗", CYAN, BOLD))
    print(color(f"║{text.center(width)}║", CYAN, BOLD))
    print(color(f"╚{border}╝", CYAN, BOLD))


def separator(width: int = 50, symbol: str = "─") -> None:
    print(color(symbol * width, YELLOW))
