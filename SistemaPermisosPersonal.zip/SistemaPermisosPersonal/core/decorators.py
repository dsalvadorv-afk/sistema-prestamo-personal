from functools import wraps
from .console import color, BOLD, CYAN, RED, YELLOW


def handle_errors(func):

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as error:
            print(color(f"\n  ✖  Error: {error}", RED, BOLD))
            input(color("  Presione Enter para continuar...", YELLOW))
            return None
    return wrapper


def operation_title(title):

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            width = 48
            border = "═" * width
            print()
            print(color(f"╔{border}╗", CYAN, BOLD))
            print(color(f"║{title.center(width)}║", CYAN, BOLD))
            print(color(f"╚{border}╝", CYAN, BOLD))
            return func(*args, **kwargs)
        return wrapper
    return decorator


def ask_continue(message="¿Desea continuar? (S/N): "):

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            while True:
                func(*args, **kwargs)

                while True:
                    option = input(color(f"\n  {message}", YELLOW, BOLD)).strip().upper()

                    if option == "S":
                        break
                    elif option == "N":
                        print(color("  Regresando al menú...", YELLOW))
                        return
                    else:
                        print(color("\n  Opción inválida.", RED))
                        print(color("  Solo puede ingresar 'S' o 'N'. Intente nuevamente.\n", RED))

        return wrapper
    return decorator
