from datetime import datetime
from .console import color, BOLD, GREEN, RED, YELLOW


class ValidationMixin:

    @staticmethod
    def validate_not_empty(value, field_name):
        if not str(value).strip():
            raise ValueError(f"{field_name} no puede estar vacío")

    @staticmethod
    def validate_full_name(value) -> bool:
        parts = str(value).strip().split()
        if len(parts) < 2:
            print("Error: Debe ingresar nombre y apellido completos")
            return False
        for part in parts:
            if len(part) < 3:
                print("Error: Cada palabra del nombre debe tener al menos 3 caracteres")
                return False
            if not part.replace("'", "").replace("-", "").isalpha():
                print("Error: El nombre solo puede contener letras")
                return False
        return True

    @staticmethod
    def input_name() -> str:
        while True:
            name = input("Nombre: ").strip()
            if ValidationMixin.validate_full_name(name):
                return name

    @staticmethod
    def validate_positive_number(value, field_name):
        if value <= 0:
            raise ValueError(f"{field_name} debe ser mayor a 0")

    @staticmethod
    def validate_permission_type(value):
        value = value.upper().strip()
        if value not in ("D", "H"):
            raise ValueError("El tipo de permiso debe ser D para días o H para horas")
        return value

    @staticmethod
    def validate_yes_no(value, field_name):
        value = value.upper().strip()
        if value not in ("S", "N"):
            raise ValueError(f"{field_name} solo acepta S o N")
        return value

    @staticmethod
    def validate_date(value, field_name):
        try:
            return datetime.strptime(value, "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError(f"{field_name} debe tener formato AAAA-MM-DD") from exc

    @staticmethod
    def validate_date_range(start_date, end_date):
        if start_date > end_date:
            raise ValueError("La fecha desde no puede ser mayor que la fecha hasta")

    @staticmethod
    def validate_id_number(id_number: str) -> bool:
        if not id_number.strip().isdigit():
            print("Error: La cédula debe contener solo números")
            return False

        if len(id_number) != 10:
            print("Error: La cédula debe tener exactamente 10 dígitos")
            return False

        province = int(id_number[:2])
        if province < 1 or province > 24:
            print("Número de cédula no válido")
            return False

        if int(id_number[2]) >= 6:
            print("Número de cédula no válido")
            return False

        total = 0
        for i in range(9):
            digit = int(id_number[i])
            if i % 2 == 0:
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit

        remainder = total % 10
        verifier = 0 if remainder == 0 else 10 - remainder

        if verifier != int(id_number[9]):
            print("Número de cédula no válido")
            return False

        return True

    @staticmethod
    def input_id_number() -> str:
        while True:
            id_number = input("Cédula: ").strip()
            if ValidationMixin.validate_id_number(id_number):
                return id_number


class LogMixin:

    LOG_PREFIX = "[LOG]"

    def log(self, message):
        print(color(f"  ✔  {LogMixin.LOG_PREFIX}: {message}", GREEN, BOLD))


class SearchMixin:

    @staticmethod
    def find_by_id(records, key, value):
        for record in records:
            if record.get(key) == value:
                return record
        return None


class DiscountMixin:

    @staticmethod
    def calculate_discount(employee, permission_type, kind, time_amount):
        if permission_type["remunerado"] == "S":
            return 0.0

        hourly_rate = employee["valor_hora"]
        if kind == "H":
            return round(hourly_rate * time_amount, 2)
        return round(hourly_rate * 8 * time_amount, 2)


class InputMixin:

    @staticmethod
    def pause():
        input(color("  Presione Enter para continuar...", YELLOW))

    @staticmethod
    def get_valid_option(prompt, valid_options):
        valid_options = [str(opt).upper() for opt in valid_options]

        while True:
            option = input(prompt).strip().upper()

            if option in valid_options:
                return option

            print("\nOpción inválida.")
            print(f"Solo puede ingresar: {', '.join(valid_options)}\n")

    @staticmethod
    def input_yes_no(prompt="Ingrese (S/N): "):
        while True:
            option = input(prompt).strip().upper()

            if option in ("S", "N"):
                return option

            print("\nOpción inválida.")
            print("Solo puede ingresar 'S' o 'N'\n")

    @staticmethod
    def input_float(prompt):
        while True:
            value = input(prompt).strip()

            try:
                number = float(value)
                if number <= 0:
                    print("El valor debe ser mayor a 0\n")
                    continue
                return number
            except ValueError:
                print("Debe ingresar solo números válidos\n")
